---
name: "swiftlint-style"
description: Write, review, and fix Swift, SwiftUI, and iOS/macOS code so it passes SwiftLint, and explain, create, or tune a .swiftlint.yml. Covers line length, force cast/try, file and type size limits, naming, whitespace, and idiomatic-Swift rules. Use this whenever the user writes or pastes Swift code, asks to make it lint-clean or "clean up the style", mentions SwiftLint, linting, .swiftlint.yml, or style warnings in Xcode or CI, or shares a SwiftLint config, even if they never say "SwiftLint" explicitly.
---

# SwiftLint style

This skill helps Claude write Swift that passes SwiftLint on the first run, review code for violations, and work with `.swiftlint.yml` files. It works for any Swift project.

## Which rules apply

1. **The user shared or pointed to a `.swiftlint.yml`:** that config wins. Read its thresholds and enabled rules, and apply those.
2. **The project's config is unknown:** use the defaults in `assets/default-swiftlint.yml` and the rules below. Say briefly that you assumed them, and offer to adjust if the project's config differs.

If a rule in the user's config contradicts anything below, follow the user's config. The numbers below are the bundled defaults, not universal truths.

## Modes

| The user wants... | Do this |
|---|---|
| Swift code written | Follow the **Coding rules** while writing. Don't narrate lint unless a rule forced a notable choice. |
| Swift code reviewed or fixed | Run the **Review checklist**, report violations by severity, then give the corrected code. |
| A config explained | Summarize rules grouped by purpose (safety, size, naming, formatting, idiomatic Swift, duplicates). |
| A config created or changed | Start from `assets/default-swiftlint.yml`, edit a copy, and state the effect of each change in one line. |

## Default severities

- **Errors (fail the build):** `force_cast`, `force_try`, `trailing_whitespace`, lines over 120 characters, files over 500 lines, type bodies over 350 lines.
- **Warnings:** files over 400 lines, type bodies over 250 lines.
- **Disabled:** `todo`, so `// TODO:` comments are fine.

Line length has warning and error both at 120, so there is no grace zone. Treat 120 as a hard wall.

## Coding rules

Each rule comes with its reason, so the spirit can be applied to cases the list doesn't cover.

**Safety**
- Avoid `as!` and `try!`. They crash at runtime on unexpected data. Use `as?` with `guard let` / `if let`, and `do/catch` or `try?`.
- Strip trailing spaces from every line, including blank lines inside functions. Editors hide them, but they are errors.

**Size**
- Keep lines at 120 characters or fewer. Break long chains and argument lists one item per line.
- Keep files under 400 lines and type bodies under 250. When a view or view model nears the limit, split it with extensions or extract subviews. Do this early, since the warning comes well before the error.
- Keep functions short and simple (`function_body_length`, `cyclomatic_complexity`), with few parameters (`function_parameter_count`), no large tuples (use a struct), and shallow nesting.

**Naming**
- `identifier_name`: descriptive names, not single letters outside conventional short-scope uses. `type_name`: types in `UpperCamelCase`.

**Formatting**
- `colon`: no space before, one after (`let name: String`). `comma`: same.
- `comment_spacing`: a space after `//`.
- `opening_brace`: one space before `{`, same line.
- `vertical_whitespace`: at most one blank line in a row.
- `trailing_newline`: exactly one newline at end of file. `leading_whitespace`: no blank lines at the top.
- `trailing_semicolon`: no `;` at statement ends.
- `trailing_comma`: follows the configured style. Multi-line collection literals typically end with or without one consistently.
- `mark`: write `// MARK: - Section` in exactly that form.
- `function_name_whitespace`: `func name(` with single spaces.

**Idiomatic Swift**
- `shorthand_operator`: `count += 1`, not `count = count + 1`.
- `syntactic_sugar`: `[Int]`, `[String: Int]`, `Int?`, not `Array<Int>`, `Dictionary<...>`, `Optional<Int>`.
- `unneeded_break_in_switch`: no trailing `break` in a case that has other code.
- `unused_closure_parameter`: use `_` for unused closure parameters.
- `unused_enumerated`: skip `.enumerated()` when you only use the element or only the index.
- `unused_optional_binding`: `if x != nil`, not `if let _ = x`.
- `for_where`: `for x in xs where cond`, not a lone `if` as the whole loop body.
- `control_statement`: no parentheses around `if` / `while` / `switch` conditions.
- `statement_position`: `} else {` on one line.
- `switch_case_alignment`: `case` aligned with `switch`.
- `empty_parentheses_with_trailing_closure`: `list.map { ... }`, not `list.map() { ... }`.
- `multiple_closures_with_trailing_closure`: with several closure arguments, label them instead of using trailing-closure syntax.
- `unavailable_condition`: prefer `#unavailable(...)` over an empty `if #available` branch.
- `dynamic_inline`: never combine `@inline(__always)` with `dynamic`.

**Duplicates**
- No duplicate imports, enum cases, dictionary-literal keys, or repeated conditions in an `if / else if` chain.

## Review checklist

1. Scan for **errors** first: `as!`, `try!`, trailing whitespace, lines over 120, file or type length.
2. Then **warnings**: approaching size limits.
3. Then the **style rules**.
4. Present findings as a table: `Line | Rule | Severity | Fix`.
5. Give the corrected code in full, unless the file is long, in which case show the changed regions.

Claude cannot run SwiftLint in this environment, so state that findings come from reading the code. Suggest running `swiftlint lint` locally to confirm, and `swiftlint --fix` for auto-correctable rules (whitespace, colons, commas, trailing newline, and similar). If a line's exact length is uncertain, say so instead of guessing.

## Writing or tuning a config

- Put the file at the project root as `.swiftlint.yml`. Paths under `excluded` are relative to that root (add asset catalogs, generated code, and third-party folders).
- Many rules in `opt_in_rules` (`colon`, `comma`, `force_cast`, `trailing_whitespace`, `file_length`, and others) are already on by default, so listing them is redundant but harmless.
- A top-level entry like `force_cast: error` sets that rule's severity. Listing the same rule in `opt_in_rules` only enables it.
- When warning and error values are equal (as in `line_length` here), the warning stage never appears. Lower the warning value for early notice.
- For legacy codebases, suggest relaxing size limits or adding a baseline instead of disabling safety rules like `force_cast`.

## Using SwiftLint

- **Xcode:** add a Run Script build phase that runs `swiftlint`, or use the SwiftLint build tool plugin.
- **CI:** `swiftlint lint --strict` fails on warnings as well as errors.
- **Local:** `swiftlint lint` to check, `swiftlint --fix` to auto-correct.
- **Single exceptions:** `// swiftlint:disable:next <rule>` for one line. Use sparingly, and explain why in a comment.
